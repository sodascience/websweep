# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['cpscraper', 'cpscraper.extractor', 'cpscraper.scraper']

package_data = \
{'': ['*']}

install_requires = \
['typer>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['cpscraper = cpscraper.main:app']}

setup_kwargs = {
    'name': 'cpscraper',
    'version': '0.1.0',
    'description': '',
    'long_description': '# corporate-scraper\n# The corporate-scraper is installable as a package now, both PIP and Script (python -m)\n\n# When pip installing, run the following commands:\n# $ cd to the cpscraper folder\n# $ poetry install\n# $ poetry build\n# $ pip install [PATH].whl\n\n# When updated the project and re-installing it, run the following commands:\n# $ cd to the cpscraper folder\n# $ poetry install\n# $ poetry build\n# $ pip install --force-reinstall [PATH].whl\n# $ cpscraper [COMMAND]\n\n# When using as script (and not installing with pip), run the following commands:\n# $ cd to the cpscraper folder\n# $ python(3) -m src.cpscraper [COMMAND]\n',
    'author': None,
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
